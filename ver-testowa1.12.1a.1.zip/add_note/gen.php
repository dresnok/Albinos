<?php
// Wygeneruj zaszyfrowane hasło do pliku configx.json
echo password_hash('deko12', PASSWORD_DEFAULT);
?>